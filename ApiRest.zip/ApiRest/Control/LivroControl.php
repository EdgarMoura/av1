<?php


include '../Model/Livro.php';
/**
 * Description of LivroControl
 *
 * @author moura
 */
class LivroControl {
    
    function insert($obj){
        $livro = new livro();
        return $livro->insert($obj);    
    }
    
    function update($obj,$idlivro){
        $livro = new Livro();
        return $livro->update($obj,$idlivro);
    }
    
    function delete($obj,$idlivro){
        $livro = new Livro();
        return $livro->delete($obj,$idlivro);
    }
    
    function find($idlivro = null){
  
    }
    
    function findAll(){
        $livro = new Livro();
        return $livro->findAll();
    }
    
}

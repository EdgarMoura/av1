<?php
	
	define('DB_NAME','api');
	define('DB_HOST', 'localhost');
	define('DB_PASS','');
	define('DB_USER','root');
?>


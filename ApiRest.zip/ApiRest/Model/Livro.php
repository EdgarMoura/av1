<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Livro
 *
 * @author moura
 */

include '../Connection/Conexao.php';

class Livro extends Conexao {

    private $idlivro;
    private $titulo;
    private $autor;
    private $genero;
    private $editora;
    private $edicao;
    private $ano;

    function __construct() {
        
    }

    function getIdlivro() {
        return $this->idlivro;
    }

    function getTitulo() {
        return $this->titulo;
    }

    function getAutor() {
        return $this->autor;
    }

    function getGenero() {
        return $this->genero;
    }

    function getEditora() {
        return $this->editora;
    }

    function getEdicao() {
        return $this->edicao;
    }

    function getAno() {
        return $this->ano;
    }

    function setIdlivro($idlivro) {
        $this->idlivro = $idlivro;
    }

    function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    function setAutor($autor) {
        $this->autor = $autor;
    }

    function setGenero($genero) {
        $this->genero = $genero;
    }

    function setEditora($editora) {
        $this->editora = $editora;
    }

    function setEdicao($edicao) {
        $this->edicao = $edicao;
    }

    function setAno($ano) {
        $this->ano = $ano;
    }

    public function insert($obj) {
        $sql = "INSERT INTO livro(titulo,autor,genero,editora,edicao,ano) VALUES (:titulo,:autor,:genero,:editora,:edicao,:ano)";
        $consulta = Conexao::prepare($sql);
        $consulta->bindValue('titulo', $obj->titulo);
        $consulta->bindValue('autor', $obj->autor);
        $consulta->bindValue('genero', $obj->genero);
        $consulta->bindValue('editora', $obj->editora);
        $consulta->bindValue('edicao', $obj->edicao);
        $consulta->bindValue('ano', $obj->ano);
        return $consulta->execute();
    }

    public function update($obj, $id = null) {
        $sql = "UPDATE livro SET titulo = :titulo, autor = :autor, genero = :genero, editora = :editora, edicao = :edicao, ano = :ano WHERE idlivro = :idlivro ";
        $consulta = Conexao::prepare($sql);
        $consulta->bindValue('titulo', $obj->titulo);
        $consulta->bindValue('autor', $obj->autor);
        $consulta->bindValue('genero', $obj->genero);
        $consulta->bindValue('editora', $obj->editora);
        $consulta->bindValue('edicao', $obj->edicao);
        $consulta->bindValue('ano', $obj->ano);
        $consulta->bindValue('idlivro', $idlivro);
        return $consulta->execute();
    }

    public function delete($obj, $idlivro = null) {
        $sql = "DELETE FROM livro WHERE idlivro = :idlivro";
        $consulta = Conexao::prepare($sql);
        $consulta->bindValue('idlivro', $idlivro);
        $consulta->execute();
    }

    public function find($id = null) {
        
    }

    public function findAll() {
        $sql = "SELECT * FROM livro";
        $consulta = Conexao::prepare($sql);
        $consulta->execute();
        return $consulta->fetchAll();
    }

}

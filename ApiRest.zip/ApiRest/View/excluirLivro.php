<?php

include '../Control/LivroControl.php';

$data = file_get_contents('php://input');
$obj = json_decode($data);


$idlivro = $obj->idlivro;

if(!empty($data)){
    $livro = new LivroControl();
    $livro->delete($obj, $idlivro);
    header('Location:listarLivro.php');
    
}

?>

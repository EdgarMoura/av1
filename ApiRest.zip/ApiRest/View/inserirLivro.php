<?php

include '../Control/LivroControl.php';

$data = file_get_contents('php://input');
$obj = json_decode($data);

if(!empty($data)){
    $livro = new LivroControl();
    $livro->insert($obj);
    header('Location:listarLivro.php');
}

?>
<?php


include '../Control/LivroControl.php';
$livro = new LivroControl();

header('Content-Type: application/json');

foreach ($livro ->findAll() as $valor) {
    echo json_encode($valor);
}

?>